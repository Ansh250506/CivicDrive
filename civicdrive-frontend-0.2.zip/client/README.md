# CivicDrive — Frontend (UI only, no backend)

A pure React + Vite frontend for CivicDrive. Runs entirely on local
component state and mock data — no server, no database, no API keys
needed. Perfect for demoing the UI/UX or wiring up a backend later.

## Setup

```bash
npm install
npm run dev
```

App runs at http://localhost:5173 — that's it, nothing else to configure.

## How "backend-less" works here

- `src/context/AuthContext.jsx` — login/signup accept any input and just
  store a fake user in memory. Refreshing the page clears the session.
- `src/services/mockData.js` — static arrays (violations, score history,
  activity feed) that the dashboards render from.
- `src/pages/ReportViolation/ReportViolation.jsx` — "submits" with a
  simulated delay, no network call.

When you're ready to connect a real backend, swap the mock functions in
`AuthContext.jsx` and the arrays in `mockData.js` for real API calls —
every component already reads from those two places only, so nothing
else needs to change.

## Structure

- `src/pages/` — one folder per route, each with its own `.jsx` and `.css`
- `src/components/` — shared UI pieces, each with its own `.jsx` and `.css`
- `src/styles/tokens.css` — global design tokens (colors, type, spacing)

## Routes

| Path | Access | Page |
|---|---|---|
| `/` | public | Landing |
| `/login`, `/signup` | public | Auth (mocked) |
| `/report` | public | Report a violation |
| `/dashboard` | after login | Citizen overview |
| `/dashboard/score` | after login | Driver score detail |
| `/authority` | after login as authority | Control center |
| `/authority/map` | after login as authority | Traffic heatmap |
| `/authority/violations` | after login as authority | Violations log |
