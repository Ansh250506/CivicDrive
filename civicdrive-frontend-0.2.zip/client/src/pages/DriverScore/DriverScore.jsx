import React from 'react'
import Sidebar from '../../components/Sidebar/Sidebar'
import ScoreBadge from '../../components/ScoreBadge/ScoreBadge'
import Reveal from '../../components/Reveal/Reveal'
import { MOCK_SCORE_HISTORY as HISTORY } from '../../services/mockData'
import './DriverScore.css'

export default function DriverScore() {
  return (
    <div className="dash-layout">
      <Sidebar variant="citizen" />
      <main className="score-main">
        <h1>Your driver score</h1>
        <p className="score-main__sub">
          A live measure of your road behaviour. It moves with verified reports, violations, and clean streaks.
        </p>

        <Reveal as="section" className="score-hero">
          <ScoreBadge score={78} size="lg" />
          <div className="score-hero__tips">
            <h3>How to improve it</h3>
            <ul>
              <li>Keep a violation-free streak — every clean week adds points.</li>
              <li>File accurate reports — verified reports earn a small bonus.</li>
              <li>Contest a violation if you believe it was logged in error.</li>
            </ul>
          </div>
        </Reveal>

        <Reveal delay={150} as="section" className="score-history">
          <h3>Score history</h3>
          {HISTORY.map((h) => (
            <div key={h.event + h.date} className="score-history__row">
              <span>{h.event}</span>
              <span className={h.change.startsWith('-') ? 'score-history__neg' : 'score-history__pos'}>
                {h.change}
              </span>
              <span className="score-history__date">{h.date}</span>
            </div>
          ))}
        </Reveal>
      </main>
    </div>
  )
}
