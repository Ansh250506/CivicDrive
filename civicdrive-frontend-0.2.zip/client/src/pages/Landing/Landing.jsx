import React from 'react'
import { Link } from 'react-router-dom'
import Reveal from '../../components/Reveal/Reveal'
import TiltCard from '../../components/TiltCard/TiltCard'
import Scene3D from '../../components/Scene3D/Scene3D'
import Counter from '../../components/Counter/Counter'
import './Landing.css'

const PILLARS = [
  {
    title: 'Real-time violation detection',
    body: 'Camera feeds are scanned for speeding, signal jumping and wrong-side driving as they happen.',
  },
  {
    title: 'Driver score',
    body: 'Every registered vehicle carries a live civic score that rises with good driving and falls with violations.',
  },
  {
    title: 'Adaptive signals',
    body: 'Signal timing adjusts to real congestion instead of a fixed clock, cutting needless idling.',
  },
  {
    title: 'Citizen reporting',
    body: 'Anyone can flag a hazard or violation with a photo and location in under a minute.',
  },
]

export default function Landing() {
  return (
    <div className="landing">
      <section className="landing__hero">
        <Reveal className="landing__hero-text">
          <h1>Traffic systems watch the road.<br />CivicDrive watches the behaviour.</h1>
          <p className="landing__lede">
            An integrated traffic management system that pairs live violation detection
            with a citizen-facing driver score, so signals, authorities and drivers
            respond to the same picture of the road.
          </p>
          <div className="landing__cta-row">
            <Link to="/signup" className="landing__cta">Get started</Link>
            <Link to="/report" className="landing__cta landing__cta--ghost">Report a violation</Link>
          </div>
        </Reveal>

        <Reveal delay={150} className="landing__hero-visual">
          <Scene3D />
          <TiltCard className="landing__hero-panel">
            <span className="landing__panel-label">Live network snapshot</span>
            <div className="landing__panel-stat">
              <span className="landing__panel-number"><Counter value={72} /></span>
              <span className="landing__panel-unit">/ 100 city avg. driver score</span>
            </div>
            <div className="landing__panel-row">
              <span>Active signals</span><span><Counter value={128} /></span>
            </div>
            <div className="landing__panel-row">
              <span>Open reports today</span><span><Counter value={14} /></span>
            </div>
            <div className="landing__panel-row">
              <span>Congestion hotspots</span><span><Counter value={3} /></span>
            </div>
          </TiltCard>
        </Reveal>
      </section>

      <Reveal as="section" className="landing__stats">
        <div className="landing__stat">
          <span className="landing__stat-value"><Counter value={60} suffix="%" /></span>
          <span className="landing__stat-label">of urban accidents trace back to driver behaviour</span>
        </div>
        <div className="landing__stat">
          <span className="landing__stat-value">1.5%</span>
          <span className="landing__stat-label">approx. of metro GDP lost yearly to congestion</span>
        </div>
        <div className="landing__stat">
          <span className="landing__stat-value"><Counter value={4} /></span>
          <span className="landing__stat-label">connected modules working as one system</span>
        </div>
      </Reveal>

      <section className="landing__pillars">
        <Reveal as="h2">One system, four working parts</Reveal>
        <div className="landing__pillar-grid">
          {PILLARS.map((p, i) => (
            <Reveal key={p.title} delay={i * 100}>
              <TiltCard maxTilt={5} className="landing__pillar">
                <h3>{p.title}</h3>
                <p>{p.body}</p>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </section>

      <Reveal as="section" className="landing__closing">
        <h2>Built for cities that need action, not another dashboard.</h2>
        <Link to="/signup" className="landing__cta">Create your account</Link>
      </Reveal>
    </div>
  )
}
