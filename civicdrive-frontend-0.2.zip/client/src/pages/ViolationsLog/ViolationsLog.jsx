import React, { useMemo, useState } from 'react'
import Sidebar from '../../components/Sidebar/Sidebar'
import Reveal from '../../components/Reveal/Reveal'
import { MOCK_VIOLATIONS, VIOLATION_TYPES } from '../../services/mockData'
import './ViolationsLog.css'

const STATUSES = ['pending', 'flagged', 'resolved']

export default function ViolationsLog() {
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [sortNewestFirst, setSortNewestFirst] = useState(true)

  const filtered = useMemo(() => {
    let rows = [...MOCK_VIOLATIONS]

    if (search.trim()) {
      const q = search.trim().toLowerCase()
      rows = rows.filter((v) => v.location.toLowerCase().includes(q))
    }
    if (typeFilter !== 'all') rows = rows.filter((v) => v.type === typeFilter)
    if (statusFilter !== 'all') rows = rows.filter((v) => v.status === statusFilter)

    rows.sort((a, b) => sortNewestFirst ? b.timestamp - a.timestamp : a.timestamp - b.timestamp)
    return rows
  }, [search, typeFilter, statusFilter, sortNewestFirst])

  return (
    <div className="dash-layout">
      <Sidebar variant="authority" />
      <main className="log-main">
        <h1>Violations log</h1>
        <p className="log-main__sub">Every reported and detected violation, searchable and filterable.</p>

        <div className="log-controls">
          <input
            className="log-search"
            type="text"
            placeholder="Search by location…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
            <option value="all">All types</option>
            {VIOLATION_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>

          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="all">All statuses</option>
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>

          <button className="log-sort-btn" onClick={() => setSortNewestFirst(!sortNewestFirst)}>
            {sortNewestFirst ? 'Newest first' : 'Oldest first'}
          </button>
        </div>

        <Reveal className="log-table-wrap">
          <table className="log-table">
            <thead>
              <tr>
                <th>Type</th>
                <th>Location</th>
                <th>Reported</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((v) => (
                <tr key={v.id}>
                  <td>{v.type}</td>
                  <td>{v.location}</td>
                  <td>{new Date(v.timestamp).toLocaleString()}</td>
                  <td>
                    <span className={`log-status log-status--${v.status}`}>{v.status}</span>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={4} className="log-empty">No violations match these filters.</td>
                </tr>
              )}
            </tbody>
          </table>
        </Reveal>

        <p className="log-count">{filtered.length} of {MOCK_VIOLATIONS.length} violations shown</p>
      </main>
    </div>
  )
}
