import React from 'react'
import Sidebar from '../../components/Sidebar/Sidebar'
import Reveal from '../../components/Reveal/Reveal'
import { MOCK_ZONES } from '../../services/mockData'
import './TrafficHeatmap.css'

function levelFor(value) {
  if (value >= 75) return 'high'
  if (value >= 45) return 'medium'
  return 'low'
}

export default function TrafficHeatmap() {
  const hotspots = [...MOCK_ZONES].sort((a, b) => b.value - a.value).slice(0, 4)

  return (
    <div className="dash-layout">
      <Sidebar variant="authority" />
      <main className="heatmap-main">
        <h1>Traffic heatmap</h1>
        <p className="heatmap-main__sub">
          Live congestion by zone. Darker tiles mean slower average speeds and higher vehicle density.
        </p>

        <div className="heatmap-body">
          <Reveal as="section" className="heatmap-grid-wrap">
            <div className="heatmap-grid">
              {MOCK_ZONES.map((zone, i) => (
                <div
                  key={zone.id}
                  className={`heatmap-tile heatmap-tile--${levelFor(zone.value)}`}
                  style={{ animationDelay: `${i * 40}ms` }}
                >
                  <span className="heatmap-tile__value">{zone.value}</span>
                  <span className="heatmap-tile__name">{zone.name}</span>
                </div>
              ))}
            </div>

            <div className="heatmap-legend">
              <span className="heatmap-legend__item"><i className="heatmap-legend__swatch heatmap-legend__swatch--low" />Free flowing (0–44)</span>
              <span className="heatmap-legend__item"><i className="heatmap-legend__swatch heatmap-legend__swatch--medium" />Moderate (45–74)</span>
              <span className="heatmap-legend__item"><i className="heatmap-legend__swatch heatmap-legend__swatch--high" />Congested (75–100)</span>
            </div>
          </Reveal>

          <Reveal delay={150} as="section" className="heatmap-hotspots">
            <h3>Top hotspots right now</h3>
            {hotspots.map((zone, i) => (
              <div key={zone.id} className="heatmap-hotspot-row">
                <span className="heatmap-hotspot-rank">{i + 1}</span>
                <span className="heatmap-hotspot-name">{zone.name}</span>
                <span className={`heatmap-hotspot-value heatmap-hotspot-value--${levelFor(zone.value)}`}>
                  {zone.value}
                </span>
              </div>
            ))}
            <p className="heatmap-hotspots__note">
              These are the zones most likely to benefit from adaptive signal
              retiming right now.
            </p>
          </Reveal>
        </div>
      </main>
    </div>
  )
}
