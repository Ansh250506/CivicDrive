import React from 'react'
import Sidebar from '../../components/Sidebar/Sidebar'
import StatCard from '../../components/StatCard/StatCard'
import ViolationCard from '../../components/ViolationCard/ViolationCard'
import Reveal from '../../components/Reveal/Reveal'
import Counter from '../../components/Counter/Counter'
import { MOCK_VIOLATIONS } from '../../services/mockData'
import './AuthorityDashboard.css'

export default function AuthorityDashboard() {
  return (
    <div className="dash-layout">
      <Sidebar variant="authority" />
      <main className="authority-main">
        <h1>Live network overview</h1>
        <p className="authority-main__sub">Congestion, violations, and signal health across the city, in real time.</p>

        <section className="dash-grid">
          <Reveal><StatCard label="Active signals" value={<Counter value={128} />} tone="accent" /></Reveal>
          <Reveal delay={80}><StatCard label="Open violations" value={<Counter value={14} />} tone="danger" /></Reveal>
          <Reveal delay={160}><StatCard label="City avg. driver score" value={<Counter value={72} />} tone="safe" /></Reveal>
        </section>

        <Reveal delay={200} as="section" className="authority-panel">
          <h3>Recent violations</h3>
          <div className="authority-violations">
            {MOCK_VIOLATIONS.slice(0, 3).map((v) => <ViolationCard key={v.id} violation={v} />)}
          </div>
        </Reveal>
      </main>
    </div>
  )
}
