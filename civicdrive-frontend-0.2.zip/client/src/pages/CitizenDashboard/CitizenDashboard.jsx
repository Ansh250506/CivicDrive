import React from 'react'
import Sidebar from '../../components/Sidebar/Sidebar'
import StatCard from '../../components/StatCard/StatCard'
import ScoreBadge from '../../components/ScoreBadge/ScoreBadge'
import Reveal from '../../components/Reveal/Reveal'
import Counter from '../../components/Counter/Counter'
import { useAuth } from '../../context/AuthContext'
import { MOCK_ACTIVITY } from '../../services/mockData'
import './CitizenDashboard.css'

export default function CitizenDashboard() {
  const { user } = useAuth()
  const firstName = user?.user_metadata?.name?.split(' ')[0] || 'there'

  return (
    <div className="dash-layout">
      <Sidebar variant="citizen" />
      <main className="dash-main">
        <h1>Hi {firstName}, here's your civic snapshot</h1>
        <p className="dash-main__sub">Your score and recent activity, updated live.</p>

        <section className="dash-grid">
          <Reveal><StatCard label="Reports filed" value={<Counter value={6} />} tone="accent" /></Reveal>
          <Reveal delay={80}><StatCard label="Violations on record" value={<Counter value={1} />} tone="danger" /></Reveal>
          <Reveal delay={160}><StatCard label="Clean months in a row" value={<Counter value={3} />} tone="safe" /></Reveal>
        </section>

        <Reveal delay={200} as="section" className="dash-score-row">
          <div className="dash-score-card">
            <ScoreBadge score={78} />
            <div>
              <h3>Your driver score</h3>
              <p>Stay above 80 to unlock priority routing alerts and reduced renewal checks.</p>
            </div>
          </div>
        </Reveal>

        <section className="dash-activity">
          <h3>Recent activity</h3>
          <ul>
            {MOCK_ACTIVITY.map((a) => (
              <li key={a.label}><span>{a.label}</span><span>{a.when}</span></li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  )
}
