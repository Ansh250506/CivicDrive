import React from 'react'
import './Scene3D.css'

/* ============================================
   Scene3D — a small rotating 3D block, built
   entirely with CSS (no 3D library).

   How it works (easy to explain to a jury):
   1. A cube has 6 faces. We render 6 <div> faces
      inside one "cube" container.
   2. Each face is pushed outward along the Z-axis
      with `translateZ()`, and the side faces are
      rotated 90deg with `rotateY()` so they form
      a box — the same trick used in any CSS-cube
      tutorial.
   3. The container has `perspective` set on its
      parent, which is what makes the rotation look
      three-dimensional instead of flat.
   4. A CSS @keyframes animation slowly spins the
      whole cube on the Y-axis, forever.
   ============================================ */
export default function Scene3D() {
  return (
    <div className="scene3d">
      <div className="scene3d__cube">
        <div className="scene3d__face scene3d__face--front" />
        <div className="scene3d__face scene3d__face--back" />
        <div className="scene3d__face scene3d__face--right" />
        <div className="scene3d__face scene3d__face--left" />
        <div className="scene3d__face scene3d__face--top" />
        <div className="scene3d__face scene3d__face--bottom" />
      </div>
      <div className="scene3d__ring" />
    </div>
  )
}
