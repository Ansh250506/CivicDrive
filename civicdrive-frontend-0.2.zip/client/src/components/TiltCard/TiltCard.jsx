import React, { useRef, useState } from 'react'
import './TiltCard.css'

/* ============================================
   TiltCard — gives an element a subtle 3D tilt
   that follows the mouse.

   How it works (easy to explain to a jury):
   1. On mouse move, we read the cursor's position
      inside the card (0 to 1 on each axis).
   2. We convert that into a small rotation angle
      (e.g. centre = 0deg, edge = +-8deg).
   3. We apply that rotation with a plain CSS
      "transform: rotateX() rotateY()" — no 3D
      library needed, just CSS 3D transforms.
   4. On mouse leave, we reset the rotation back to 0.
   ============================================ */
export default function TiltCard({ children, className = '', maxTilt = 8 }) {
  const cardRef = useRef(null)
  const [style, setStyle] = useState({})

  function handleMouseMove(e) {
    const card = cardRef.current
    if (!card) return

    const rect = card.getBoundingClientRect()
    const x = (e.clientX - rect.left) / rect.width   // 0 -> 1 across the card
    const y = (e.clientY - rect.top) / rect.height    // 0 -> 1 down the card

    const rotateY = (x - 0.5) * (maxTilt * 2)   // left/right tilt
    const rotateX = (0.5 - y) * (maxTilt * 2)   // up/down tilt

    setStyle({
      transform: `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`,
    })
  }

  function handleMouseLeave() {
    setStyle({ transform: 'perspective(700px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)' })
  }

  return (
    <div
      ref={cardRef}
      className={`tilt-card ${className}`}
      style={style}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      {children}
    </div>
  )
}
