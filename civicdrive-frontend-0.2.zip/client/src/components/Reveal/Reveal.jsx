import React from 'react'
import { useReveal } from '../../hooks/useReveal'
import './Reveal.css'

/* Wraps any content and fades/slides it in once it scrolls
   into view. `delay` (ms) staggers a group of items. */
export default function Reveal({ children, delay = 0, as: Tag = 'div', className = '' }) {
  const [ref, visible] = useReveal()

  return (
    <Tag
      ref={ref}
      className={`reveal ${visible ? 'reveal--visible' : ''} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  )
}
