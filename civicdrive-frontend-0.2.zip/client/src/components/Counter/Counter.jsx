import React, { useEffect, useState } from 'react'
import { useReveal } from '../../hooks/useReveal'

/* ============================================
   Counter — animates a number counting up from
   0 to `value` once it scrolls into view.

   How it works: we reuse useReveal to know when
   the number is visible, then step it upward
   with setInterval until it reaches the target.
   ============================================ */
export default function Counter({ value, suffix = '', duration = 900 }) {
  const [ref, visible] = useReveal()
  const [display, setDisplay] = useState(0)

  useEffect(() => {
    if (!visible) return
    const steps = 30
    const stepTime = duration / steps
    const increment = value / steps
    let current = 0
    let count = 0

    const id = setInterval(() => {
      count += 1
      current += increment
      setDisplay(count === steps ? value : Math.round(current))
      if (count >= steps) clearInterval(id)
    }, stepTime)

    return () => clearInterval(id)
  }, [visible, value, duration])

  return <span ref={ref}>{display}{suffix}</span>
}
