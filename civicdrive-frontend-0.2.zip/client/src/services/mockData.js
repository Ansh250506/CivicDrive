/* ============================================
   Mock data layer — stands in for a real backend.
   Swap these for real API/Supabase calls later;
   every component only touches this file, never
   fake data directly.
   ============================================ */

export const MOCK_VIOLATIONS = [
  { id: 1, type: 'Signal jumping', location: 'MG Circle', timestamp: Date.now() - 1000 * 60 * 20, status: 'pending' },
  { id: 2, type: 'Speeding', location: 'Ring Road Flyover', timestamp: Date.now() - 1000 * 60 * 90, status: 'flagged' },
  { id: 3, type: 'Wrong-side driving', location: '5th Cross', timestamp: Date.now() - 1000 * 60 * 200, status: 'resolved' },
  { id: 4, type: 'No helmet / seatbelt', location: 'Station Road', timestamp: Date.now() - 1000 * 60 * 240, status: 'pending' },
  { id: 5, type: 'Illegal parking', location: 'Central Market', timestamp: Date.now() - 1000 * 60 * 300, status: 'resolved' },
  { id: 6, type: 'Speeding', location: 'Outer Ring Road', timestamp: Date.now() - 1000 * 60 * 340, status: 'flagged' },
  { id: 7, type: 'Signal jumping', location: 'Junction 9', timestamp: Date.now() - 1000 * 60 * 420, status: 'resolved' },
  { id: 8, type: 'Other hazard', location: 'Riverside Bridge', timestamp: Date.now() - 1000 * 60 * 480, status: 'pending' },
  { id: 9, type: 'Wrong-side driving', location: 'MG Circle', timestamp: Date.now() - 1000 * 60 * 600, status: 'flagged' },
  { id: 10, type: 'No helmet / seatbelt', location: 'College Road', timestamp: Date.now() - 1000 * 60 * 720, status: 'resolved' },
]

/* Congestion zones for the heatmap grid — value is 0-100 (higher = more congested) */
export const MOCK_ZONES = [
  { id: 'z1', name: 'MG Circle', value: 88 },
  { id: 'z2', name: 'Ring Road Flyover', value: 74 },
  { id: 'z3', name: '5th Cross', value: 35 },
  { id: 'z4', name: 'Station Road', value: 52 },
  { id: 'z5', name: 'Central Market', value: 91 },
  { id: 'z6', name: 'Outer Ring Road', value: 63 },
  { id: 'z7', name: 'Junction 9', value: 28 },
  { id: 'z8', name: 'Riverside Bridge', value: 45 },
  { id: 'z9', name: 'College Road', value: 58 },
  { id: 'z10', name: 'Tech Park Gate', value: 82 },
  { id: 'z11', name: 'Old Town Square', value: 22 },
  { id: 'z12', name: 'Airport Road', value: 67 },
]

export const MOCK_SCORE_HISTORY = [
  { event: 'Clean week bonus', change: '+2', date: 'Sep 20' },
  { event: 'Report verified in your favour', change: '+3', date: 'Sep 12' },
  { event: 'Signal jumping — MG Circle', change: '-8', date: 'Aug 30' },
  { event: 'Account created', change: '+50', date: 'Aug 01' },
]

export const MOCK_ACTIVITY = [
  { label: 'Report filed — Illegal parking, Station Road', when: '2 days ago' },
  { label: 'Score increased +2 — clean week', when: '5 days ago' },
  { label: 'Violation logged — Signal jumping, MG Circle', when: '3 weeks ago' },
]

export const VIOLATION_TYPES = [
  'Signal jumping',
  'Speeding',
  'Wrong-side driving',
  'No helmet / seatbelt',
  'Illegal parking',
  'Other hazard',
]
