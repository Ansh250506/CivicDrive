import { useEffect, useRef, useState } from 'react'

/* ============================================
   useReveal — a tiny hook that tells a component
   whether it has scrolled into view.

   How it works (easy to explain to a jury):
   1. We attach a ref to the DOM element we want to watch.
   2. The browser's built-in IntersectionObserver watches
      that element and fires a callback when it crosses
      the viewport boundary.
   3. Once it's visible, we flip `visible` to true and
      stop watching (so the animation only plays once).
   ============================================ */
export function useReveal(threshold = 0.15) {
  const ref = useRef(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const node = ref.current
    if (!node) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true)
          observer.disconnect()
        }
      },
      { threshold }
    )

    observer.observe(node)
    return () => observer.disconnect()
  }, [threshold])

  return [ref, visible]
}
