import React from 'react'
import { Routes, Route } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import Navbar from './components/Navbar/Navbar'
import Footer from './components/Footer/Footer'
import ProtectedRoute from './components/ProtectedRoute/ProtectedRoute'

import Landing from './pages/Landing/Landing'
import Login from './pages/Login/Login'
import Signup from './pages/Signup/Signup'
import ReportViolation from './pages/ReportViolation/ReportViolation'
import CitizenDashboard from './pages/CitizenDashboard/CitizenDashboard'
import DriverScore from './pages/DriverScore/DriverScore'
import AuthorityDashboard from './pages/AuthorityDashboard/AuthorityDashboard'
import NotFound from './pages/NotFound/NotFound'

import './App.css'

export default function App() {
  return (
    <AuthProvider>
      <div className="app-shell">
        <Navbar />

        <div className="app-content">
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/report" element={<ReportViolation />} />

            <Route
              path="/dashboard"
              element={
                <ProtectedRoute requireRole="citizen">
                  <CitizenDashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/dashboard/score"
              element={
                <ProtectedRoute requireRole="citizen">
                  <DriverScore />
                </ProtectedRoute>
              }
            />

            <Route
              path="/authority"
              element={
                <ProtectedRoute requireRole="authority">
                  <AuthorityDashboard />
                </ProtectedRoute>
              }
            />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>

        <Footer />
      </div>
    </AuthProvider>
  )
}
