import React, { useState } from 'react'
import { VIOLATION_TYPES } from '../../services/mockData'
import './ReportViolation.css'

/* Frontend-only: submitting just simulates a network call and
   shows a success state. Wire this up to a real backend later. */

export default function ReportViolation() {
  const [form, setForm] = useState({ type: VIOLATION_TYPES[0], location: '', description: '' })
  const [image, setImage] = useState(null)
  const [status, setStatus] = useState('idle') // idle | sending | done

  function update(field) {
    return (e) => setForm({ ...form, [field]: e.target.value })
  }

  function handleSubmit(e) {
    e.preventDefault()
    setStatus('sending')
    setTimeout(() => {
      setStatus('done')
      setForm({ type: VIOLATION_TYPES[0], location: '', description: '' })
      setImage(null)
    }, 600)
  }

  return (
    <div className="report-page">
      <div className="report-page__intro">
        <h1>Report a violation</h1>
        <p>
          Seen risky driving, a broken signal, or a road hazard? Two minutes here helps the
          system flag the hotspot and adjust that driver's score.
        </p>
      </div>

      <form className="report-form" onSubmit={handleSubmit}>
        <label className="report-field">
          <span>What did you see?</span>
          <select value={form.type} onChange={update('type')}>
            {VIOLATION_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </label>

        <label className="report-field">
          <span>Location</span>
          <input
            required
            value={form.location}
            onChange={update('location')}
            placeholder="e.g. MG Road & 5th Cross signal"
          />
        </label>

        <label className="report-field">
          <span>Description (optional)</span>
          <textarea
            rows={4}
            value={form.description}
            onChange={update('description')}
            placeholder="Anything that helps — vehicle colour, plate fragment, time of day…"
          />
        </label>

        <label className="report-field">
          <span>Photo evidence (optional)</span>
          <input type="file" accept="image/*" onChange={(e) => setImage(e.target.files[0])} />
          {image && <span className="report-field__hint">{image.name} selected</span>}
        </label>

        <button className="report-submit" type="submit" disabled={status === 'sending'}>
          {status === 'sending' ? 'Submitting…' : 'Submit report'}
        </button>

        {status === 'done' && (
          <p className="report-status report-status--success">
            Report submitted. Thank you — it now appears on the authority dashboard.
          </p>
        )}
      </form>
    </div>
  )
}
