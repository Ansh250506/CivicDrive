import React from 'react'
import { Link } from 'react-router-dom'
import './NotFound.css'

export default function NotFound() {
  return (
    <div className="not-found">
      <h1>404</h1>
      <p>This road doesn't exist on our map.</p>
      <Link to="/" className="not-found__link">Back to home</Link>
    </div>
  )
}
