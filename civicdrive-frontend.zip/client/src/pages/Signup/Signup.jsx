import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import '../Login/Login.css'

export default function Signup() {
  const { signup } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'citizen' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  function update(field) {
    return (e) => setForm({ ...form, [field]: e.target.value })
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      await signup(form.email, form.password, form.name, form.role)
      navigate(form.role === 'authority' ? '/authority' : '/dashboard')
    } catch (err) {
      setError(err.message || 'Could not create your account. Try again.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="auth-page">
      <form className="auth-card" onSubmit={handleSubmit}>
        <h1>Create your account</h1>
        <p className="auth-card__sub">Join as a citizen to report and track, or as an authority to manage the network.</p>

        {error && <div className="auth-card__error">{error}</div>}

        <label className="auth-field">
          <span>Full name</span>
          <input required value={form.name} onChange={update('name')} placeholder="Your name" />
        </label>

        <label className="auth-field">
          <span>Email</span>
          <input type="email" required value={form.email} onChange={update('email')} placeholder="you@example.com" />
        </label>

        <label className="auth-field">
          <span>Password</span>
          <input type="password" required minLength={6} value={form.password} onChange={update('password')} placeholder="At least 6 characters" />
        </label>

        <label className="auth-field">
          <span>Account type</span>
          <select value={form.role} onChange={update('role')}>
            <option value="citizen">Citizen</option>
            <option value="authority">Traffic authority</option>
          </select>
        </label>

        <button className="auth-submit" type="submit" disabled={busy}>
          {busy ? 'Creating account…' : 'Create account'}
        </button>

        <p className="auth-card__footer">
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </form>
    </div>
  )
}
