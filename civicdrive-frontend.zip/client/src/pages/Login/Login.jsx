import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import './Login.css'

export default function Login() {
  const { login, role } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  function update(field) {
    return (e) => setForm({ ...form, [field]: e.target.value })
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      await login(form.email, form.password)
      navigate(role === 'authority' ? '/authority' : '/dashboard')
    } catch (err) {
      setError(err.message || 'Could not log in. Check your details and try again.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="auth-page">
      <form className="auth-card" onSubmit={handleSubmit}>
        <h1>Welcome back</h1>
        <p className="auth-card__sub">Log in to check your driver score or manage the network.</p>

        {error && <div className="auth-card__error">{error}</div>}

        <label className="auth-field">
          <span>Email</span>
          <input type="email" required value={form.email} onChange={update('email')} placeholder="you@example.com" />
        </label>

        <label className="auth-field">
          <span>Password</span>
          <input type="password" required value={form.password} onChange={update('password')} placeholder="••••••••" />
        </label>

        <button className="auth-submit" type="submit" disabled={busy}>
          {busy ? 'Logging in…' : 'Log in'}
        </button>

        <p className="auth-card__footer">
          New to CivicDrive? <Link to="/signup">Create an account</Link>
        </p>
      </form>
    </div>
  )
}
