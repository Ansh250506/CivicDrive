import React from 'react'
import Sidebar from '../../components/Sidebar/Sidebar'
import StatCard from '../../components/StatCard/StatCard'
import ViolationCard from '../../components/ViolationCard/ViolationCard'
import { MOCK_VIOLATIONS } from '../../services/mockData'
import './AuthorityDashboard.css'

export default function AuthorityDashboard() {
  return (
    <div className="dash-layout">
      <Sidebar variant="authority" />
      <main className="authority-main">
        <h1>Live network overview</h1>
        <p className="authority-main__sub">Congestion, violations, and signal health across the city, in real time.</p>

        <section className="dash-grid">
          <StatCard label="Active signals" value="128" tone="accent" />
          <StatCard label="Open violations" value="14" tone="danger" />
          <StatCard label="City avg. driver score" value="72" tone="safe" />
        </section>

        <section className="authority-panel">
          <h3>Recent violations</h3>
          <div className="authority-violations">
            {MOCK_VIOLATIONS.map((v) => <ViolationCard key={v.id} violation={v} />)}
          </div>
        </section>
      </main>
    </div>
  )
}
