import React from 'react'
import { Link } from 'react-router-dom'
import './Landing.css'

const PILLARS = [
  {
    title: 'Real-time violation detection',
    body: 'Camera feeds are scanned for speeding, signal jumping and wrong-side driving as they happen.',
  },
  {
    title: 'Driver score',
    body: 'Every registered vehicle carries a live civic score that rises with good driving and falls with violations.',
  },
  {
    title: 'Adaptive signals',
    body: 'Signal timing adjusts to real congestion instead of a fixed clock, cutting needless idling.',
  },
  {
    title: 'Citizen reporting',
    body: 'Anyone can flag a hazard or violation with a photo and location in under a minute.',
  },
]

const STATS = [
  { value: '60%', label: 'of urban accidents trace back to driver behaviour' },
  { value: '1.5%', label: 'of metro GDP lost yearly to congestion' },
  { value: '4', label: 'connected modules working as one system' },
]

export default function Landing() {
  return (
    <div className="landing">
      <section className="landing__hero">
        <div className="landing__hero-text">
          <h1>Traffic systems watch the road.<br />CivicDrive watches the behaviour.</h1>
          <p className="landing__lede">
            An integrated traffic management system that pairs live violation detection
            with a citizen-facing driver score, so signals, authorities and drivers
            respond to the same picture of the road.
          </p>
          <div className="landing__cta-row">
            <Link to="/signup" className="landing__cta">Get started</Link>
            <Link to="/report" className="landing__cta landing__cta--ghost">Report a violation</Link>
          </div>
        </div>

        <div className="landing__hero-panel">
          <span className="landing__panel-label">Live network snapshot</span>
          <div className="landing__panel-stat">
            <span className="landing__panel-number">72</span>
            <span className="landing__panel-unit">/ 100 city avg. driver score</span>
          </div>
          <div className="landing__panel-row">
            <span>Active signals</span><span>128</span>
          </div>
          <div className="landing__panel-row">
            <span>Open reports today</span><span>14</span>
          </div>
          <div className="landing__panel-row">
            <span>Congestion hotspots</span><span>3</span>
          </div>
        </div>
      </section>

      <section className="landing__stats">
        {STATS.map((s) => (
          <div key={s.label} className="landing__stat">
            <span className="landing__stat-value">{s.value}</span>
            <span className="landing__stat-label">{s.label}</span>
          </div>
        ))}
      </section>

      <section className="landing__pillars">
        <h2>One system, four working parts</h2>
        <div className="landing__pillar-grid">
          {PILLARS.map((p) => (
            <div key={p.title} className="landing__pillar">
              <h3>{p.title}</h3>
              <p>{p.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="landing__closing">
        <h2>Built for cities that need action, not another dashboard.</h2>
        <Link to="/signup" className="landing__cta">Create your account</Link>
      </section>
    </div>
  )
}
