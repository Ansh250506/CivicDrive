import React from 'react'
import './ViolationCard.css'

export default function ViolationCard({ violation }) {
  const { type, location, timestamp, status = 'pending' } = violation

  return (
    <div className="violation-card">
      <div className={`violation-card__status violation-card__status--${status}`} />
      <div className="violation-card__body">
        <div className="violation-card__top">
          <span className="violation-card__type">{type}</span>
          <span className={`violation-card__badge violation-card__badge--${status}`}>
            {status}
          </span>
        </div>
        <span className="violation-card__location">{location}</span>
        <span className="violation-card__time">
          {new Date(timestamp).toLocaleString()}
        </span>
      </div>
    </div>
  )
}
