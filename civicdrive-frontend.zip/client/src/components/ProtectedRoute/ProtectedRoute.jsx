import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import Loader from '../Loader/Loader'

export default function ProtectedRoute({ children, requireRole }) {
  const { user, role, loading } = useAuth()

  if (loading) return <Loader label="Checking your session…" />
  if (!user) return <Navigate to="/login" replace />
  if (requireRole && role !== requireRole) return <Navigate to="/" replace />

  return children
}
