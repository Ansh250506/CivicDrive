import React from 'react'
import './Footer.css'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer__row">
        <span className="footer__brand">CivicDrive</span>
        <span className="footer__tag">An integrated traffic management system for safer metro roads.</span>
      </div>
      <div className="footer__meta">
        <span>&copy; {new Date().getFullYear()} CivicDrive Team</span>
        <span>Built for civic hackathon submission</span>
      </div>
    </footer>
  )
}
