import React from 'react'
import './StatCard.css'

export default function StatCard({ label, value, trend, tone = 'neutral' }) {
  return (
    <div className={`stat-card stat-card--${tone}`}>
      <span className="stat-card__label">{label}</span>
      <span className="stat-card__value">{value}</span>
      {trend && <span className="stat-card__trend">{trend}</span>}
    </div>
  )
}
