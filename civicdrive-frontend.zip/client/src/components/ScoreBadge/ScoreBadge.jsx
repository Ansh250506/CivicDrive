import React from 'react'
import './ScoreBadge.css'

function tierFor(score) {
  if (score >= 80) return { label: 'Excellent', tone: 'safe' }
  if (score >= 50) return { label: 'Needs improvement', tone: 'warn' }
  return { label: 'At risk', tone: 'danger' }
}

export default function ScoreBadge({ score = 0, size = 'md' }) {
  const tier = tierFor(score)
  return (
    <div className={`score-badge score-badge--${size} score-badge--${tier.tone}`}>
      <div className="score-badge__ring">
        <span className="score-badge__number">{score}</span>
      </div>
      <span className="score-badge__label">{tier.label}</span>
    </div>
  )
}
