import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import './Navbar.css'

export default function Navbar() {
  const { user, role, logout } = useAuth()
  const [open, setOpen] = useState(false)
  const navigate = useNavigate()

  async function handleLogout() {
    await logout()
    navigate('/')
  }

  return (
    <header className="navbar">
      <Link to="/" className="navbar__brand">
        <span className="navbar__brand-mark">●</span> CivicDrive
      </Link>

      <button
        className="navbar__toggle"
        onClick={() => setOpen(!open)}
        aria-label="Toggle navigation menu"
        aria-expanded={open}
      >
        <span /><span /><span />
      </button>

      <nav className={`navbar__links ${open ? 'navbar__links--open' : ''}`}>
        <Link to="/" onClick={() => setOpen(false)}>Home</Link>
        <Link to="/report" onClick={() => setOpen(false)}>Report a Violation</Link>
        {user && role === 'citizen' && (
          <Link to="/dashboard" onClick={() => setOpen(false)}>My Dashboard</Link>
        )}
        {user && role === 'authority' && (
          <Link to="/authority" onClick={() => setOpen(false)}>Control Center</Link>
        )}

        {!user ? (
          <Link to="/login" className="navbar__cta" onClick={() => setOpen(false)}>
            Log in
          </Link>
        ) : (
          <button className="navbar__cta navbar__cta--ghost" onClick={handleLogout}>
            Log out
          </button>
        )}
      </nav>
    </header>
  )
}
