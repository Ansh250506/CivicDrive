import React from 'react'
import { NavLink } from 'react-router-dom'
import './Sidebar.css'

const CITIZEN_LINKS = [
  { to: '/dashboard', label: 'Overview', icon: '◧' },
  { to: '/dashboard/score', label: 'My Driver Score', icon: '◑' },
  { to: '/report', label: 'Report Violation', icon: '◈' },
]

const AUTHORITY_LINKS = [
  { to: '/authority', label: 'Live Overview', icon: '◧' },
  { to: '/authority/map', label: 'Traffic Heatmap', icon: '◎' },
  { to: '/authority/violations', label: 'Violations Log', icon: '⚠' },
]

export default function Sidebar({ variant = 'citizen' }) {
  const links = variant === 'authority' ? AUTHORITY_LINKS : CITIZEN_LINKS

  return (
    <aside className="sidebar">
      <nav className="sidebar__nav">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            end
            className={({ isActive }) =>
              `sidebar__link ${isActive ? 'sidebar__link--active' : ''}`
            }
          >
            <span className="sidebar__icon">{link.icon}</span>
            {link.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
