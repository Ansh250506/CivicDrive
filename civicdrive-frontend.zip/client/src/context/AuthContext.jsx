import React, { createContext, useContext, useState } from 'react'

/* ============================================
   Frontend-only auth context.
   Holds session state in memory so every page can
   read `user` / `role` without a backend attached.
   Replace the three functions below with real API
   calls once a backend is wired up.
   ============================================ */

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [role, setRole] = useState(null) // 'citizen' | 'authority'
  const [loading] = useState(false)

  async function login(email, _password) {
    // Placeholder: accepts any credentials and signs the user in locally.
    const fakeUser = { id: 'local-user', email, user_metadata: { name: email.split('@')[0] } }
    setUser(fakeUser)
    setRole('citizen')
    return fakeUser
  }

  async function signup(email, _password, name, selectedRole = 'citizen') {
    const fakeUser = { id: 'local-user', email, user_metadata: { name, role: selectedRole } }
    setUser(fakeUser)
    setRole(selectedRole)
    return fakeUser
  }

  async function logout() {
    setUser(null)
    setRole(null)
  }

  return (
    <AuthContext.Provider value={{ user, role, loading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
