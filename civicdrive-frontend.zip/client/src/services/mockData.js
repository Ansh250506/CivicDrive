/* ============================================
   Mock data layer — stands in for a real backend.
   Swap these for real API/Supabase calls later;
   every component only touches this file, never
   fake data directly.
   ============================================ */

export const MOCK_VIOLATIONS = [
  { id: 1, type: 'Signal jumping', location: 'MG Circle', timestamp: Date.now() - 1000 * 60 * 20, status: 'pending' },
  { id: 2, type: 'Speeding', location: 'Ring Road Flyover', timestamp: Date.now() - 1000 * 60 * 90, status: 'flagged' },
  { id: 3, type: 'Wrong-side driving', location: '5th Cross', timestamp: Date.now() - 1000 * 60 * 200, status: 'resolved' },
]

export const MOCK_SCORE_HISTORY = [
  { event: 'Clean week bonus', change: '+2', date: 'Sep 20' },
  { event: 'Report verified in your favour', change: '+3', date: 'Sep 12' },
  { event: 'Signal jumping — MG Circle', change: '-8', date: 'Aug 30' },
  { event: 'Account created', change: '+50', date: 'Aug 01' },
]

export const MOCK_ACTIVITY = [
  { label: 'Report filed — Illegal parking, Station Road', when: '2 days ago' },
  { label: 'Score increased +2 — clean week', when: '5 days ago' },
  { label: 'Violation logged — Signal jumping, MG Circle', when: '3 weeks ago' },
]

export const VIOLATION_TYPES = [
  'Signal jumping',
  'Speeding',
  'Wrong-side driving',
  'No helmet / seatbelt',
  'Illegal parking',
  'Other hazard',
]
